// Función para comprobar y aplicar actualizaciones
async function checkForUpdate() {
    try {
        // Obtener la información de actualización desde la URL
        const response = await fetch("https://gatitodigital.github.io/DigitalTeam/Extencion/Actualizacion.json");
        const updateInfo = await response.json();

        // Obtener la versión actual de la extensión
        const currentVersion = chrome.runtime.getManifest().version;

        // Comparar las versiones
        if (updateInfo.version && updateInfo.version !== currentVersion) {
            // Si hay una versión más reciente disponible, mostrar una notificación al usuario
            alert("¡Hay una nueva versión disponible! Se actualizará automáticamente.");
            
            // Descargar e instalar la actualización
            chrome.runtime.reload();
        } else {
            // Si no hay actualizaciones disponibles, no hacer nada
            console.log("La extensión está actualizada.");
        }
    } catch (error) {
        console.error("Error al comprobar la actualización:", error);
    }
}

// Comprobar actualizaciones al iniciar la extensión
chrome.runtime.onInstalled.addListener(checkForUpdate);

// Comprobar actualizaciones periódicamente cada 24 horas
setInterval(checkForUpdate, 1 * 60 * 60 * 1000); // 24 horas en milisegundos
