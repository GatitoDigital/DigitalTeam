chrome.runtime.onInstalled.addListener(function(details) {
  // Verificar actualizaciones solo después de la instalación
  if (details.reason === "install") {
    checkForUpdate();
  }
});

function checkForUpdate() {
  // Realizar una solicitud para obtener la última versión desde tu servidor
  fetch('https://gatitodigital.github.io/DigitalTeam/Extencion/manifest.json')
    .then(response => response.json())
    .then(data => {
      const latestVersion = data.version;

      // Obtener la versión actual de la extensión
      const currentVersion = chrome.runtime.getManifest().version;

      // Comparar versiones
      if (latestVersion !== currentVersion) {
        // Si hay una versión más reciente, actualizar la extensión
        chrome.runtime.reload();
      }
    })
    .catch(error => console.error('Error al verificar actualizaciones:', error));
}
