document.addEventListener('DOMContentLoaded', function() {
    var contentContainer = document.getElementById('content');
    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'https://gatitodigital.github.io/DigitalTeam/Extencion/popup/index.html', true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            contentContainer.innerHTML = xhr.responseText;
        }
    };
    xhr.send();
});
