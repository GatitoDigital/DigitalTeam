function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const sidebarWidth = sidebar.offsetWidth;
    const screenWidth = window.innerWidth;

    if (sidebar.style.right === '0px') {
        sidebar.style.right = `-${sidebarWidth}px`;
    } else {
        sidebar.style.right = '0px';
    }
}
